# Databricks notebook source
import logging.config
from src.features.build_features import FeatureEngineering
from src.data.pyspark import PySpark
import pandas as pd
from azure.keyvault.secrets import SecretClient
from pyspark.sql import SparkSession
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential


logger = logging.getLogger(__name__)

def get_dbutils(spark):
    try:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)

    except KeyError:
        from pyspark.dbutils import DBUtils
        dbutils = DBUtils(spark)
    return dbutils

def run_pipeline(pyspark):
    """[Run a previously trained model to retrieve a prediction based on the test data derived from
    the train/test split]

    Args:
        pyspark (object): [PySpark helper class used for spark / databricks operations]
    """    
    try:
        #Run curation job to process data into correct structure for feature engineering
        feature_eng = FeatureEngineering(pyspark)
        #Create distance based features to be used for training dataset
        feature_eng.create_distance_features()
        
        
        
    except Exception as e:
        raise(e)


if __name__ in "__main__":
  
  logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(module)s : %(lineno)d - %(message)s',
                      level=logging.INFO)
  logging.getLogger("py4j").setLevel(logging.ERROR)
    
  try:
    #Create Spark Session and Databricks utilities used for curation jobs
    spark = SparkSession.builder.getOrCreate()

    #Create secret_client to retrieve secrets
    credential = DefaultAzureCredential()
    secret_client = SecretClient(vault_url="https://gridiron-kv.vault.azure.net/", credential=credential)

    #Create helper pyspark class and run nfl pipeline
    pyspark = PySpark(None, secret_client)
    run_pipeline(pyspark)

  except Exception as e:
      raise(e)
