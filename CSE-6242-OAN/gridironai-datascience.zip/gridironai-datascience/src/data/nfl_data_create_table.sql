CREATE TABLE fact_scouting (
gameId INTEGER,	
playId SMALLINT,	
snapDetail VARCHAR(50),	
snapTime DOUBLE,	
operationTime DOUBLE,	
hangTime DOUBLE,	
kickType VARCHAR(50),	
kickDirectionIntended VARCHAR(50),	
kickDirectionActual	VARCHAR(50),	
returnDirectionIntended	VARCHAR(50),	
returnDirectionActual	VARCHAR(50),	
missedTackler VARCHAR(50),	
assistTackler VARCHAR(50),	
tackler	VARCHAR(50),	
kickoffReturnFormation VARCHAR(50),	
gunners	VARCHAR(50),	
puntRushers	VARCHAR(MAX),	
specialTeamsSafeties VARCHAR(50),	
vises VARCHAR(50),	
kickContactType VARCHAR(50)
);


CREATE TABLE fact_tracking (
gameTime DATETIME,	
x FLOAT,	
y FLOAT,	
s	FLOAT,	
a	FLOAT,	
dis	FLOAT,	
o	FLOAT,	
dir	FLOAT,	
event VARCHAR(10),	
nflId INTEGER,	
displayName VARCHAR(100),	
jerseyNumber SMALLINT,
position VARCHAR(10),	
team VARCHAR(10),	
frameId SMALLINT,	
gameId	INTEGER,	
playId SMALLINT,	
playDirection VARCHAR(10)
);

CREATE TABLE dim_player (
nflId INTEGER,
height VARCHAR(10),
weight SMALLINT,	
birthDate DATE,
collegeName VARCHAR(100), 	
Position VARCHAR(100),
displayName VARCHAR(100) 
);

CREATE TABLE dim_games (
gameId INTEGER,	
season SMALLINT,	
week SMALLINT,	
gameDate DATE,	
gameTimeEastern VARCHAR(100),	
homeTeamAbbr VARCHAR(100),	
visitorTeamAbbr VARCHAR(100)
);

CREATE TABLE fact_plays(
gameId INTEGER,	
playId SMALLINT,	
playDescription VARCHAR(MAX),	
quarter VARCHAR(100),	
down SMALLINT,	
yardsToGo SMALLINT,	
possessionTeam VARCHAR(10),	
specialTeamsPlayType VARCHAR(100),	
specialTeamsResult VARCHAR(100),	
kickerId INTEGER,	
returnerId INTEGER,	
kickBlockerId VARCHAR(100),	
yardlineSide VARCHAR(100),	
yardlineNumber VARCHAR(100),	
gameClock VARCHAR(100),	
penaltyCodes VARCHAR(100),	
penaltyJerseyNumbers VARCHAR(100),	
penaltyYards VARCHAR(100),	
preSnapHomeScore VARCHAR(100),	
preSnapVisitorScore VARCHAR(100),	
passResult VARCHAR(100),	
kickLength VARCHAR(100),	
kickReturnYardage VARCHAR(100),	
playResult VARCHAR(100),	
absoluteYardlineNumber VARCHAR(100)
);


