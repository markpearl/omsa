# Databricks notebook source
#Databricks source notebook
#imports required
import mlflow
import os
import matplotlib.pyplot as plt
import mlflow.sklearn
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import tempfile
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from mlflow.tracking import MlflowClient
import lightgbm as lgb
import mlflow.lightgbm
from mlflow.models.signature import infer_signature

# COMMAND ----------

#Punt return data for training
training_df = spark.sql("""
                        SELECT 
                        gameId, 
                        playId, 
                        frameid, 
                        quarter, 
                        down, 
                        yardsToGo,
                        preSnapHomeScore, 
                        preSnapVisitorScore,
                        CAST(snapTime AS FLOAT) as snapTime ,
                        CAST(hangTime AS FLOAT) as hangTime, 
                        CAST(operationTime AS FLOAT) as operationTime,
                        CAST(kickLength AS INTEGER) as kickLength,
                        CAST(penaltyYards AS INTEGER) as penaltyYards,
                        playResult,
                        s as speedYardsSecondReturner,
                        a as speedYardsSecondSquaredReturner,
                        dis as distanceTravelledPriorReturner,
                        CAST(o AS FLOAT) as returnerOrientationDegrees,
                        CAST(dir AS FLOAT) as returnerAngleOfPlayerMotion,
                        distance_returner_gunner1,
                        distance_returner_gunner2,
                        y_football_rescaled,
                        kickReturnYardage
                        FROM gridiron_delta.training_punts_returns
                        WHERE substring(gameId, 1, 4) == '2018' OR substring(gameId, 1, 4) == '2019'
                """)

# COMMAND ----------

#Create variables for feature table, key columns and model label
id_cols = ['gameId','playId','frameid']
label = 'kickReturnYardage'

# End any existing runs (in the case this notebook is being run for a second time)
mlflow.end_run()
 
# Start an mlflow run, which is needed for the feature store to log the model
mlflow.start_run() 
 
# Since the rounded timestamp columns would likely cause the model to overfit the data 
# unless additional feature engineering was performed, exclude them to avoid training on them.
exclude_columns = ["down","playResult"]
exclude_columns.extend(id_cols)

# COMMAND ----------

# Display the training dataframe, and note that it contains both the raw input data and the features from the Feature Store, like `dropoff_is_weekend`
display(training_df)

# COMMAND ----------

features_and_label = [col for col in training_df.columns if col not in exclude_columns]
 
# Collect data into a Pandas array for training
data = training_df.toPandas()[features_and_label]
data['kickReturnYardage'] = data['kickReturnYardage'].replace('NA', 0)

train, test = train_test_split(data, random_state=123)
X_train = train.drop([label], axis=1)
X_test = test.drop([label], axis=1)
y_train = train[label]
y_test = test[label]

# COMMAND ----------

mlflow.end_run()
#Simple experiment with lgbm 
with mlflow.start_run(run_name="expected_punt_returns-xgb-nofs RUN") as run:
    # Create model, train it, and create predictions
    mlflow.lightgbm.autolog()
    train_lgb_dataset = lgb.Dataset(X_train, label=y_train.values)
    test_lgb_dataset = lgb.Dataset(X_test, label=y_test.values)

    param = {"num_leaves": 32, "objective": "regression", "metric": "rmse"}
    num_rounds = 100

    # Train a lightGBM model
    model = lgb.train(
      param, train_lgb_dataset, num_rounds
    )
    
    # Log model
    mlflow.sklearn.log_model(model, "expected_punt_returns-lgb")

    #Get predictions in order to log MSE
    predictions = model.predict(X_test)

    # Create metrics
    rmse = mean_squared_error(y_test, predictions,squared=False)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    # Log metrics
    mlflow.log_metrics({"rmse": rmse, "mae": mae, "r2": r2})

    runID = run.info.run_id
    experimentID = run.info.experiment_id


    print(f"Inside MLflow Run with run_id `{runID}` and experiment_id `{experimentID}`")
    mlflow.end_run()

# COMMAND ----------

lgb.plot_importance(model,importance_type='split')

# COMMAND ----------

lgb.plot_importance(model,importance_type='gain')

# COMMAND ----------

def log_rf(experimentID, run_name, params, X_train, X_test, y_train, y_test):
  with mlflow.start_run(experiment_id=experimentID, run_name=run_name) as run:
    # Create model, train it, and create predictions
    X_train = X_train.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    y_train = y_train.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    X_test = X_test.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    rf = RandomForestRegressor(**params)
    rf.fit(X_train, y_train)
    predictions = rf.predict(X_test)

    # Log model
    mlflow.sklearn.log_model(rf, "expected_punt_returns-rf")

    # Log params
    mlflow.log_params(params)

    # Create metrics
    mse = mean_squared_error(y_test, predictions,squared=False)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    # Log metrics=
    mlflow.log_metrics({"rmse": mse, "mae": mae, "r2": r2})

    # Create feature importance
    print(list(zip(data.columns, rf.feature_importances_)))
    importance = pd.DataFrame(list(zip(list(data.columns), rf.feature_importances_)),
                                columns=["Feature", "Importance"]
                              ).sort_values("Importance", ascending=False)
    importance.head()

    # Log importances using a temporary file
    temp = tempfile.NamedTemporaryFile(prefix="feature-importance-", suffix=".csv")
    temp_name = temp.name
    try:
      importance.to_csv(temp_name, index=False)
      mlflow.log_artifact(temp_name, "feature-importance.csv")
    finally:
      temp.close() # Delete the temp file

    # Create plot
    fig, ax = plt.subplots()
        
    importance.plot.bar(ax=ax)
    plt.xlabel("Predicted values for Price ($)")
    plt.ylabel("Residual")
    plt.title("Residual Plot")

    # Log residuals using a temporary file
    temp = tempfile.NamedTemporaryFile(prefix="residuals-", suffix=".png")
    temp_name = temp.name
    try:
      fig.savefig(temp_name)
      mlflow.log_artifact(temp_name, "residuals.png")
    finally:
      temp.close() # Delete the temp file

    display(fig)
    return run.info.run_id, rf

# COMMAND ----------

#Punt return data for training
input_df_2020 = spark.sql("""
                        SELECT 
                        gameId, 
                        playId, 
                        frameid, 
                        quarter, 
                        down, 
                        yardsToGo,
                        preSnapHomeScore, 
                        preSnapVisitorScore,
                        CAST(snapTime AS FLOAT) as snapTime ,
                        CAST(hangTime AS FLOAT) as hangTime, 
                        CAST(operationTime AS FLOAT) as operationTime,
                        CAST(kickLength AS INTEGER) as kickLength,
                        CAST(penaltyYards AS INTEGER) as penaltyYards,
                        playResult,
                        s as speedYardsSecondReturner,
                        a as speedYardsSecondSquaredReturner,
                        dis as distanceTravelledPriorReturner,
                        CAST(o AS FLOAT) as returnerOrientationDegrees,
                        CAST(dir AS FLOAT) as returnerAngleOfPlayerMotion,
                        distance_returner_gunner1,
                        distance_returner_gunner2,
                        y_football_rescaled,
                        kickReturnYardage
                        FROM gridiron_delta.training_punts_returns
                        WHERE substring(gameId, 1, 4) == '2020'
                """)


features_and_label = [col for col in input_df_2020.columns if col not in exclude_columns]
 
# Collect data into a Pandas array for training
keys_df = input_df_2020.toPandas()[['gameId','playId','frameid','kickReturnYardage']]
data_2020 = input_df_2020.toPandas()[features_and_label]
data_2020['kickReturnYardage'] = data['kickReturnYardage'].replace('NA', 0)

data_final = data_2020.drop([label], axis=1)
predictions = model.predict(data_final)

# train, test = train_test_split(data, random_state=123)
# X_train = train.drop([label], axis=1)
# X_test = test.drop([label], axis=1)
# y_train = train[label]
# y_test = test[label]

# COMMAND ----------

predictions_df = pd.DataFrame(list(predictions), columns = ['expected_yards_returned'])

# COMMAND ----------

join_df = pd.merge(keys_df, predictions_df, left_index=True, right_index=True)

# COMMAND ----------

sparkDF=spark.createDataFrame(join_df) 
sparkDF.write.format('delta').saveAsTable('gridiron_delta.punt_analysis_2020_predictions')

# COMMAND ----------

params = {
  "n_estimators": 100,
  "max_depth": 5,
  "random_state": 42
}

run_id, model = log_rf(experimentID, "expected_punt_returns-rf-nofs RUN", params, X_train, X_test, y_train, y_test)

# COMMAND ----------

import shap
# compute SHAP values
explainer = shap.Explainer(model, X_train)
shap_values = explainer(X_train)

# COMMAND ----------

shap.plots.waterfall(shap_values[0])

# COMMAND ----------

shaps_fx_ge_20 = [shap for shap in shap_values if (shap.base_values + sum(shap.values)) > 20]

# COMMAND ----------

shap.plots.waterfall(shaps_fx_ge_20[5])

# COMMAND ----------

from sklearn.datasets import make_hastie_10_2
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.inspection import PartialDependenceDisplay

fig, ax = plt.subplots(figsize=(12, 6))
features_plot =  ["distance_returner_gunner1", "distanceTravelledPriorReturner"]
ax.set_title("Random Forest Regressor")
rf_disp = PartialDependenceDisplay.from_estimator(
    model, X_train, features_plot, ax=ax, line_kw={"color": "red"}
)

# COMMAND ----------

# make plot.
# compute SHAP values
#explainer = shap.Explainer(model, X_train)
#shap_values = explainer(X_train)
#shap.dependence_plot('distance_returner_gunner1', shap_values[1], X_train)
shap.summary_plot(shap_values, X_train)

# COMMAND ----------

# Log the trained model with MLflow and package it with feature lookup information. 
log_model(
  model,
  artifact_path="model_packaged",
  flavor=mlflow.lightgbm,
  training_set=training_set,
  registered_model_name="expected_punt_return_yardage"
)

# COMMAND ----------

from mlflow.tracking.client import MlflowClient

client = MlflowClient()

client.delete_model_version(
  name=  'expected_punt_return_yardage',
  version=4
)

# COMMAND ----------

import joblib
filename = '/dbfs/expected_yards.joblib.pkl'
joblib.dump(model, filename, compress=9)

# COMMAND ----------

X_train.to_csv('/dbfs/X_train.csv')
