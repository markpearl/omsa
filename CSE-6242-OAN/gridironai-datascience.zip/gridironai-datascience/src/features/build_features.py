# -*- coding: utf-8 -*-
import logging
import math
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import udf,split,regexp_extract,trim,abs,col,round,when
from pyspark.sql.types import *

logger = logging.getLogger(__name__)
 
class FeatureEngineering:
    
    def __init__(self, pyspark: object):
        """[Constructor for curation job to create dataset used as input for 
        feature engineering]
        
        Arguments:
            pyspark {object} -- [Represents pyspark object for helper class]
        """           
        self.pyspark = pyspark
        
    def create_distance_features(self): 
        """[Join tracking data with the football position pivoted to it's own columns with plays data, 
        then calculate distance between returner and football]
        """
        try:
            #Retrieve data from joined table containing each return and fair catch and position of football
            logger.info("Reading from table gp_join_tracking to get all return data at the frame the ball was caught by receiver")
            join_df = self.pyspark.spark.sql("""SELECT * FROM gridiron_delta.gp_join_tracking""")
            join_df.cache()
            #Create seperate columns for each gunner on the play
            jersey_regex_pattern = r'^\w+\s(\d+)' #Extracts 40 for the input string PHI 40
            team_regex_pattern = r'^(\w+)\s\d+' #Extracts PHI for the input string PHI 40
            logger.info("Create columns for determining jersey # for each gunner")
            join_df = join_df.withColumn('gunner1_jersey_num', regexp_extract(trim(split(join_df['gunners'],';')[0]),jersey_regex_pattern,1))\
                             .withColumn('gunner2_jersey_num', regexp_extract(trim(split(join_df['gunners'],';')[1]),jersey_regex_pattern,1))\
                             .withColumn('defense_team_abbr', regexp_extract(trim(split(join_df['gunners'],';')[0]),team_regex_pattern,1))
            join_df.createOrReplaceTempView("join_df")
            #logger.info(f"Length of join_df is {join_df.count()}")
            #Determine team abbreviation for tracking data
            tracking_df = self.pyspark.spark.sql(f"""SELECT t.*, g.homeTeamAbbr, g.visitorTeamAbbr
                                                     FROM
                                                     gridiron_delta.fact_tracking t 
                                                     INNER JOIN
                                                     gridiron_delta.dim_games g
                                                     ON t.gameId = g.gameId
                                                 """)
            tracking_df = tracking_df.withColumn('team_abbr', when(trim(col("team")) == 'home',  col("homeTeamAbbr")).otherwise(col("visitorTeamAbbr")))
            tracking_df.createOrReplaceTempView('tracking_df')
            #logger.info(f"Length of tracking_df is {tracking_df.count()}")
            #Create a dataframe joining the join result to get position of both gunners on the play
            features_df = self.pyspark.spark.sql(f"""SELECT t.*, g1.x as x_gunner1, g1.y as y_gunner1, g2.x as x_gunner2, g2.y as y_gunner2 \
                                                     FROM join_df t \
                                                     INNER JOIN tracking_df g1 \
                                                     ON t.gameId = g1.gameId AND t.playId = g1.playId AND t.frameId = g1.frameId AND t.gunner1_jersey_num = g1.jerseyNumber \
                                                     INNER JOIN tracking_df g2 \
                                                     ON t.gameId = g2.gameId AND t.playId = g2.playId AND t.frameId = g2.frameId AND t.gunner2_jersey_num = g2.jerseyNumber \
                                                     WHERE t.possessionTeam = g1.team_abbr AND t.possessionTeam = g2.team_abbr
                                                 """)
            logger.info(f"Length of features_df is {features_df.count()}")
            distance_udf = udf(calculate_distance_two_points,FloatType())
            #Create features for measure
            logger.info("Creating features for measuring distance from receiver to each gunner")
            features_df = features_df.withColumn("distance_returner_gunner1",distance_udf(features_df.x,features_df.x_gunner1,features_df.y,features_df.y_gunner1))\
                             .withColumn("distance_returner_gunner2",distance_udf(features_df.x,features_df.x_gunner2,features_df.y,features_df.y_gunner2))
            #Get the relative rescaled y position
            logger.info("Calculating featuring for y-scale-adjusted of the football at the time of receival by returner")
            features_df = features_df.withColumn('y_football_rescaled',round(100*(26.65 - abs(col('y_football') - 26.65))/26.65,2))
            logger.info("Writing feature engineering results to training table")
            self.pyspark.generate_table_ddl(features_df,'gridiron_delta.training_punts_returns','delta',None,None,False)
            self.pyspark.initial_overwrite_load(features_df, 'delta','overwrite',None,'gridiron_delta.training_punts_returns')           
            
        except Exception as e:
            raise(e)        

    def write_dataframe_tempresults(self, input_df: object, location: str, view_name: str):
        """[Write dataframe to temporary location]

        Args:
            input_df (object): [Input dataframe to be written to temporary location]
            location (str): [Temporary location for dataframe]
            view_name (str): [Temporary view name]
        """        
        try:
            self.pyspark.initial_overwrite_load(input_df, 'delta','overwrite',None,location)
            temp_df = self.pyspark.read_dataframe(location, 'DELTA')
            temp_df.createOrReplaceTempView(view_name)
            
        except Exception as e:
            raise(e)

def calculate_distance_two_points(x1: float, x2: float, y1: float, y2: float ):
    """[Calculate distance between two points]

    Args:
        x1 (float): [X coordinate for first point]
        x2 (float): [X coordinate for second point]
        y1 (float): [Y coordinate for first point]
        y2 (float): [Y coordinate for second point]
    """        
    try:
        #Calcualate distance between two points
        distance =  math.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        return distance
    
    except Exception as e:
        raise(e)