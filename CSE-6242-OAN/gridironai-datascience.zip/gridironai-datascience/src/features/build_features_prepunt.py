# Databricks notebook source
speed_df = spark.sql("""
   SELECT nflId, MAX(s) max_speed
   FROM gridiron_delta.fact_tracking
   WHERE nflId != 'NA'
   GROUP BY nflId
""")
speed_df.createOrReplaceTempView("player_speed")

# COMMAND ----------

import logging
import math
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.functions import udf,split,regexp_extract,trim,abs,col,round,when,greatest,least
from pyspark.sql.types import *

# COMMAND ----------

plays_df = spark.sql("""SELECT * FROM gridiron_delta.fact_plays WHERE specialTeamsPlayType='Punt'""")
scouting_df = spark.sql("""SELECT * FROM gridiron_delta.fact_scouting""")
games_df = spark.sql("""SELECT * FROM gridiron_delta.dim_games""")
join_df = plays_df.join(scouting_df, ['gameId', 'playId']).join(games_df, 'gameId')
join_df.cache()

# COMMAND ----------

#Create seperate columns for each gunner on the play
jersey_regex_pattern = r'^\w+\s(\d+)' #Extracts 40 for the input string PHI 40
team_regex_pattern = r'^(\w+)\s\d+' #Extracts PHI for the input string PHI 40
join_df = join_df.withColumn('gunner1_jersey_num', regexp_extract(trim(split(join_df['gunners'], ';')[0]), jersey_regex_pattern, 1))\
                 .withColumn('gunner2_jersey_num', regexp_extract(trim(split(join_df['gunners'],';')[1]),jersey_regex_pattern,1))\
                 .withColumn('gunner_team_abbr', regexp_extract(trim(split(join_df['gunners'],';')[0]),team_regex_pattern,1))
join_df.createOrReplaceTempView("join_df")

# COMMAND ----------

# Determine whether the gunners are on the home or away team
join_df = join_df.withColumn('kick_home_away', when(col('gunner_team_abbr')==col('homeTeamAbbr'), 'home').otherwise('away'))

# get the gunner nflId values
frame_df = spark.sql("""SELECT gameId, playId, team, jerseyNumber, nflId FROM gridiron_delta.fact_tracking WHERE frameId=1""")
write_df = frame_df.write.format('delta').option("overwriteSchema","true").mode('overwrite')
write_df.save('/tmp/tracking/')
frame_df = spark.read.format('delta').load('/tmp/tracking/') 
frame_df.cache()
g1 = join_df.alias('j').join(frame_df.alias('f'), on=[col('j.gameId')==col('f.gameId'), col('j.playId')==col('f.playId'), col('j.kick_home_away') == col('f.team'), col('j.gunner1_jersey_num') == col('f.jerseyNumber')]).withColumnRenamed('nflId', 'gunner1_nflId')
g2 = join_df.alias('j').join(frame_df.alias('f'), on=[col('j.gameId')==col('f.gameId'), col('j.playId')==col('f.playId'), col('j.kick_home_away') == col('f.team'), col('j.gunner2_jersey_num') == col('f.jerseyNumber')]).withColumnRenamed('nflId', 'gunner2_nflId')
g1 = g1.select('j.gameId', 'j.playId', 'gunner1_nflId')
g2 = g2.select('j.gameId', 'j.playId', 'gunner2_nflId')
join_df = join_df.join(g1, ['gameId', 'playId']).join(g2, ['gameId', 'playId'])

# COMMAND ----------

# add gunner speed columns
j = join_df.alias('j').join(speed_df.alias('s'), col('j.gunner1_nflId') == col('s.nflId')).withColumnRenamed('max_speed', 'gunner1_speed').drop('s.nflId')
j = j.alias('j').join(speed_df.alias('s'), col('j.gunner2_nflId') == col('s.nflId')).withColumnRenamed('max_speed', 'gunner2_speed').drop('s.nflId')
j = j.alias('j').join(speed_df.alias('s'), col('j.returnerId') == col('s.nflId')).withColumnRenamed('max_speed', 'returner_speed').drop('s.nflId')
join_df = j

# COMMAND ----------

# Order the gunner speeds so gunner1_speed is always greater than gunner2_speed
join_df = join_df.withColumn('faster_gunner_speed', greatest('gunner1_speed', 'gunner2_speed')).withColumn('slower_gunner_speed', least('gunner1_speed', 'gunner2_speed'))

# COMMAND ----------

# calculate average and max kick length for each kicker
kick_length_df = spark.sql("""
SELECT kickerId, AVG(kickLength) avg_kick_length, MAX(kickLength) max_kick_length
FROM gridiron_delta.fact_plays
WHERE specialTeamsPlayType='Punt'
AND kickLength != 'NA'
GROUP BY kickerId
""")
kick_length_df.show(100)

# COMMAND ----------

# Add average and max kick length columns
join_df = join_df.join(kick_length_df, 'kickerId')

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS gridiron_delta.pre_punt;
# MAGIC CREATE TABLE gridiron_delta.pre_punt
# MAGIC SELECT gameId, playId, absoluteYardlineNumber, faster_gunner_speed, slower_gunner_speed, returner_speed, avg_kick_length, CAST(max_kick_length AS Integer), playResult
# MAGIC FROM join_dfs

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS gridiron_delta.training_pre_punt;
# MAGIC CREATE TABLE gridiron_delta.training_pre_punt
# MAGIC SELECT absoluteYardlineNumber, faster_gunner_speed, slower_gunner_speed, returner_speed, avg_kick_length, CAST(max_kick_length AS Integer), playResult
# MAGIC FROM gridiron_delta.pre_punt
# MAGIC WHERE substring(gameId, 1, 4) == '2018' OR substring(gameId, 1, 4) == '2019'

# COMMAND ----------

pre_punt_df = spark.sql("""SELECT * FROM gridiron_delta.training_pre_punt""")

# COMMAND ----------

pre_punt_df.head(10)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS gridiron_delta.simulate_pre_punt;
# MAGIC CREATE TABLE gridiron_delta.simulate_pre_punt
# MAGIC SELECT absoluteYardlineNumber, faster_gunner_speed, slower_gunner_speed, returner_speed, avg_kick_length, CAST(max_kick_length AS Integer), playResult
# MAGIC FROM gridiron_delta.pre_punt
# MAGIC WHERE substring(gameId, 1, 4) == '2020'

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS gridiron_delta.pre_punt_2020;
# MAGIC CREATE TABLE gridiron_delta.pre_punt_2020
# MAGIC SELECT *
# MAGIC FROM gridiron_delta.pre_punt
# MAGIC WHERE substring(gameId, 1, 4) == '2020'

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM gridiron_delta.pre_punt_2020 limit 10

# COMMAND ----------


