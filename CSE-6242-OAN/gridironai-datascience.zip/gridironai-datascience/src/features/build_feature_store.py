# Databricks notebook source
from databricks import feature_store

# COMMAND ----------

#Create training dataframe to select features used to input into feature_store
input_df = spark.sql("""
                        SELECT 
                        gameId, 
                        playId, 
                        frameid, 
                        quarter, 
                        down, 
                        yardsToGo,
                        preSnapHomeScore, 
                        preSnapVisitorScore,
                        CAST(snapTime AS FLOAT) as snapTime ,
                        CAST(hangTime AS FLOAT) as hangTime, 
                        CAST(operationTime AS FLOAT) as operationTime,
                        CAST(kickLength AS INTEGER) as kickLength,
                        CAST(penaltyYards AS INTEGER) as penaltyYards,
                        playResult,
                        s as speedYardsSecondReturner,
                        a as speedYardsSecondSquaredReturner,
                        dis as distanceTravelledPriorReturner,
                        CAST(o AS FLOAT) as returnerOrientationDegrees,
                        CAST(dir AS FLOAT) as returnerAngleOfPlayerMotion,
                        kickReturnYardage
                        FROM gridiron_delta.training_punts_returns
                        """)

# COMMAND ----------

#Create training dataframe to select features used to input into feature_store
features_df = spark.sql("""
                        SELECT 
                        gameId, 
                        playId, 
                        frameid, 
                        distance_returner_gunner1,
                        distance_returner_gunner2,
                        y_football_rescaled
                        FROM gridiron_delta.training_punts_returns
                        """)

# COMMAND ----------

#Create feature store object and start writing to feature table
fs = feature_store.FeatureStoreClient()
spark.conf.set("spark.sql.shuffle.partitions", "5")
fs.create_feature_table(
    name="gridiron_delta.punt_return_features",
    keys=["gameId", "playId", "frameid"],
    features_df=features_df,
    partition_columns="gameId",
    description="Features used for nfl data to predict expected return yardage on a punt return",
)
