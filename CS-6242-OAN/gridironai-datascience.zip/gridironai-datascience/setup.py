from setuptools import find_packages, setup

setup(
    name='src',
    packages=find_packages(),
    version='0.1.0',
    description='This project is aimed at developing models with NFL games / events data to analyze impact of special teams on game outcomes.',
    author='GridironAI',
    license='MIT',
)