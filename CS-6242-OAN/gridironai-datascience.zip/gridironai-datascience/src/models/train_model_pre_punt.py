# Databricks notebook source
#Databricks source notebook
#imports required
import mlflow
import os
import matplotlib.pyplot as plt
import mlflow.sklearn
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import tempfile
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from mlflow.tracking import MlflowClient
import lightgbm as lgb
import mlflow.lightgbm
from mlflow.models.signature import infer_signature


# COMMAND ----------

#Punt return data for training
training_df = spark.sql("""SELECT * FROM gridiron_delta.training_pre_punt""")

# COMMAND ----------

#Create variables for feature table, key columns and model label
label = 'playResult'

# End any existing runs (in the case this notebook is being run for a second time)
mlflow.end_run()
 
# Start an mlflow run, which is needed for the feature store to log the model
mlflow.start_run() 


# COMMAND ----------

# Display the training dataframe, and note that it contains both the raw input data and the features from the Feature Store, like `dropoff_is_weekend`
display(training_df)

# COMMAND ----------

# Collect data into a Pandas array for training
data = training_df.toPandas()
data[label] = data[label].replace('NA', 0)

train, test = train_test_split(data, random_state=123)
X_train = train.drop([label], axis=1)
X_test = test.drop([label], axis=1)
y_train = train[label]
y_test = test[label]

# COMMAND ----------

# Display the training dataframe, and note that it contains both the raw input data and the features from the Feature Store, like `dropoff_is_weekend`
display(X_train)

# COMMAND ----------

# Display the training dataframe, and note that it contains both the raw input data and the features from the Feature Store, like `dropoff_is_weekend`
y_train.head(10)

# COMMAND ----------

mlflow.end_run()
#Simple experiment with lgbm 
with mlflow.start_run(run_name="expected_playResult-xgb-nofs RUN") as run:
    # Create model, train it, and create predictions
    mlflow.lightgbm.autolog()
    train_lgb_dataset = lgb.Dataset(X_train, label=y_train.values)
    test_lgb_dataset = lgb.Dataset(X_test, label=y_test.values)

    param = {"num_leaves": 32, "objective": "regression", "metric": "rmse"}
    num_rounds = 100

    # Train a lightGBM model
    model = lgb.train(
      param, train_lgb_dataset, num_rounds
    )
    
    # Log model
    mlflow.sklearn.log_model(model, "expected_punt_returns-lgb")

    #Get predictions in order to log MSE
    predictions = model.predict(X_test)

    # Create metrics
    rmse = mean_squared_error(y_test, predictions,squared=False)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    # Log metrics
    mlflow.log_metrics({"rmse": rmse, "mae": mae, "r2": r2})

    runID = run.info.run_id
    experimentID = run.info.experiment_id


    print(f"Inside MLflow Run with run_id `{runID}` and experiment_id `{experimentID}`")
    mlflow.end_run()

# COMMAND ----------

 mlflow.end_run()

# COMMAND ----------

lgb.plot_importance(model,importance_type='split')

# COMMAND ----------

lgb.plot_importance(model,importance_type='gain')

# COMMAND ----------

list(data.columns)

# COMMAND ----------

def log_rf(experimentID, run_name, params, X_train, X_test, y_train, y_test):
  with mlflow.start_run(experiment_id=experimentID, run_name=run_name) as run:
    # Create model, train it, and create predictions
    X_train = X_train.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    y_train = y_train.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    X_test = X_test.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    rf = RandomForestRegressor(**params)
    rf.fit(X_train, y_train)
    predictions = rf.predict(X_test)
    
    
    # Log model
    mlflow.sklearn.log_model(rf, "expected_playResult-rf")

    # Log params
    mlflow.log_params(params)

    # Create metrics
    mse = mean_squared_error(y_test, predictions,squared=False)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    # Log metrics=
    mlflow.log_metrics({"rmse": mse, "mae": mae, "r2": r2})

    # Create feature importance
    print(list(zip(data.columns, rf.feature_importances_)))
    importance = pd.DataFrame(list(zip(list(data.columns), rf.feature_importances_)),
                                columns=["Feature", "Importance"]
                              ).sort_values("Importance", ascending=False)
    importance.head()

    # Log importances using a temporary file
    temp = tempfile.NamedTemporaryFile(prefix="feature-importance-", suffix=".csv")
    temp_name = temp.name
    try:
      importance.to_csv(temp_name, index=False)
      mlflow.log_artifact(temp_name, "feature-importance.csv")
    finally:
      temp.close() # Delete the temp file

    # Create plot
    fig, ax = plt.subplots()
        
    importance.plot.bar(ax=ax)
    plt.xlabel("Predicted values for Price ($)")
    plt.ylabel("Residual")
    plt.title("Residual Plot")

    # Log residuals using a temporary file
    temp = tempfile.NamedTemporaryFile(prefix="residuals-", suffix=".png")
    temp_name = temp.name
    try:
      fig.savefig(temp_name)
      mlflow.log_artifact(temp_name, "residuals.png")
    finally:
      temp.close() # Delete the temp file

    display(fig)
    return run.info.run_id, rf

# COMMAND ----------

params = {
  "n_estimators": 100,
  "max_depth": 5,
  "random_state": 42
}

run_id, model = log_rf(experimentID, "expected_playResult-rf-nofs RUN", params, X_train, X_test, y_train, y_test)

# COMMAND ----------

import shap
# compute SHAP values
explainer = shap.Explainer(model, X_train)
shap_values = explainer(X_train)

# COMMAND ----------

shap.plots.waterfall(shap_values[0])

# COMMAND ----------

shap.summary_plot(shap_values, X_train)

# COMMAND ----------

shap_values[0].values

# COMMAND ----------

negative_faster_gunner = [{idx:shap} for idx,shap in enumerate(shap_values) for elem in shap.values if elem < -15]

# COMMAND ----------

negative_faster_gunner

# COMMAND ----------

shap.plots.waterfall(shap_values[446])

# COMMAND ----------

shap.plots.waterfall(shap_values[1160])

# COMMAND ----------

shap.plots.waterfall(shap_values[1633])

# COMMAND ----------

shaps_fx_ge_20 = [shap for shap in shap_values if (shap.base_values + sum(shap.values)) > 20]

# COMMAND ----------

# Log the trained model with MLflow and package it with feature lookup information. 
mlflow.sklearn.log_model(
  model,
  artifact_path="model_packaged",
  flavor=mlflow.lightgbm,
  training_set=training_set,
  registered_model_name="expected_play_result"
)


# COMMAND ----------

from mlflow.tracking.client import MlflowClient

client = MlflowClient()

client.delete_model_version(
  name=  'expected_play_result',
  version=1
)

# COMMAND ----------


