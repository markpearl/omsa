# Databricks notebook source
#Databricks source notebook
#imports required
from databricks import feature_store
from databricks.feature_store import FeatureLookup
import mlflow
import os
import matplotlib.pyplot as plt
import mlflow.sklearn
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import tempfile
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from mlflow.tracking import MlflowClient
import lightgbm as lgb
import mlflow.lightgbm
from mlflow.models.signature import infer_signature


# COMMAND ----------

#Create feature store client
fs = feature_store.FeatureStoreClient()

#Create variables for feature table, key columns and model label
id_cols = ['gameId','playId','frameid']
label = 'kickReturnYardage'
punt_return_features_table = "gridiron_delta.punt_return_features"

#Extract the column names from the feature table
features_list = [row[0] for row in spark.sql(f'SHOW COLUMNS FROM {punt_return_features_table}').collect() if row[0] not in id_cols and row[0] != label]

# COMMAND ----------

#Create list for feature lookups to reference in training dataset
punt_return_feature_lookups = []
for feature in features_list:
    #Create feature lookup
    feature_lookup = FeatureLookup( 
      table_name = punt_return_features_table,
      feature_names = feature,
      lookup_key = id_cols
    )
    #Append to list
    punt_return_feature_lookups.append(feature_lookup)
    
#Punt return data for training
train = spark.sql("""
                        SELECT 
                        gameId, 
                        playId, 
                        frameid, 
                        quarter, 
                        down, 
                        yardsToGo,
                        preSnapHomeScore, 
                        preSnapVisitorScore,
                        CAST(snapTime AS FLOAT) as snapTime ,
                        CAST(hangTime AS FLOAT) as hangTime, 
                        CAST(operationTime AS FLOAT) as operationTime,
                        CAST(kickLength AS INTEGER) as kickLength,
                        CAST(penaltyYards AS INTEGER) as penaltyYards,
                        playResult,
                        s as speedYardsSecondReturner,
                        a as speedYardsSecondSquaredReturner,
                        dis as distanceTravelledPriorReturner,
                        CAST(o AS FLOAT) as returnerOrientationDegrees,
                        CAST(dir AS FLOAT) as returnerAngleOfPlayerMotion,
                        kickReturnYardage
                        FROM gridiron_delta.training_punts_returns
                """)

# COMMAND ----------

# End any existing runs (in the case this notebook is being run for a second time)
mlflow.end_run()
 
# Start an mlflow run, which is needed for the feature store to log the model
mlflow.start_run() 
 
# Since the rounded timestamp columns would likely cause the model to overfit the data 
# unless additional feature engineering was performed, exclude them to avoid training on them.
exclude_columns = ["down","playResult"]
exclude_columns.extend(id_cols)
# Create the training set that includes the raw input data merged with corresponding features from both feature tables
training_set = fs.create_training_set(
  df = train,
  feature_lookups = punt_return_feature_lookups,
  label = label,
  exclude_columns = exclude_columns
)
 
# Load the TrainingSet into a dataframe which can be passed into sklearn for training a model
training_df = training_set.load_df()

# COMMAND ----------

# Display the training dataframe, and note that it contains both the raw input data and the features from the Feature Store, like `dropoff_is_weekend`
display(training_df)

# COMMAND ----------

features_and_label = [col for col training_df.columns
 
# Collect data into a Pandas array for training
data = training_df.toPandas()[features_and_label]
data['kickReturnYardage'] = data['kickReturnYardage'].replace('NA', 0)

train, test = train_test_split(data, random_state=123)
X_train = train.drop([label], axis=1)
X_test = test.drop([label], axis=1)
y_train = train[label]
y_test = test[label]

# COMMAND ----------

#Simple experiment with lgbm 
with mlflow.start_run(run_name="expected_punt_returns-xgb RUN") as run:
    # Create model, train it, and create predictions
    mlflow.lightgbm.autolog()
    train_lgb_dataset = lgb.Dataset(X_train, label=y_train.values)
    test_lgb_dataset = lgb.Dataset(X_test, label=y_test.values)

    param = {"num_leaves": 32, "objective": "regression", "metric": "rmse"}
    num_rounds = 100

    # Train a lightGBM model
    model = lgb.train(
      param, train_lgb_dataset, num_rounds
    )
    
    # Log model
    mlflow.sklearn.log_model(model, "expected_punt_returns-lgb")

    #Get predictions in order to log MSE
    predictions = model.predict(X_test)

    # Create metrics
    rmse = mean_squared_error(y_test, predictions,squared=False)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    # Log metrics
    mlflow.log_metrics({"rmse": rmse, "mae": mae, "r2": r2})

    runID = run.info.run_id
    experimentID = run.info.experiment_id


    print(f"Inside MLflow Run with run_id `{runID}` and experiment_id `{experimentID}`")
    mlflow.end_run()

# COMMAND ----------

 mlflow.end_run()

# COMMAND ----------

lgb.plot_importance(model,importance_type='split')

# COMMAND ----------

lgb.plot_importance(model,importance_type='gain')

# COMMAND ----------

list(data.columns)

# COMMAND ----------

def log_rf(experimentID, run_name, params, X_train, X_test, y_train, y_test):
  with mlflow.start_run(experiment_id=experimentID, run_name=run_name) as run:
    # Create model, train it, and create predictions
    X_train = X_train.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    y_train = y_train.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    X_test = X_test.replace((np.inf, -np.inf, np.nan), 0).reset_index(drop=True)
    rf = RandomForestRegressor(**params)
    rf.fit(X_train, y_train)
    predictions = rf.predict(X_test)

    # Log model
    mlflow.sklearn.log_model(rf, "expected_punt_returns-rf")

    # Log params
    mlflow.log_params(params)

    # Create metrics
    mse = mean_squared_error(y_test, predictions,squared=False)
    mae = mean_absolute_error(y_test, predictions)
    r2 = r2_score(y_test, predictions)

    # Log metrics=
    mlflow.log_metrics({"rmse": mse, "mae": mae, "r2": r2})

    # Create feature importance
    print(list(zip(data.columns, rf.feature_importances_)))
    importance = pd.DataFrame(list(zip(list(data.columns), rf.feature_importances_)),
                                columns=["Feature", "Importance"]
                              ).sort_values("Importance", ascending=False)
    importance.head()

    # Log importances using a temporary file
    temp = tempfile.NamedTemporaryFile(prefix="feature-importance-", suffix=".csv")
    temp_name = temp.name
    try:
      importance.to_csv(temp_name, index=False)
      mlflow.log_artifact(temp_name, "feature-importance.csv")
    finally:
      temp.close() # Delete the temp file

    # Create plot
    fig, ax = plt.subplots()
        
    importance.plot.bar(ax=ax)
    plt.xlabel("Predicted values for Price ($)")
    plt.ylabel("Residual")
    plt.title("Residual Plot")

    # Log residuals using a temporary file
    temp = tempfile.NamedTemporaryFile(prefix="residuals-", suffix=".png")
    temp_name = temp.name
    try:
      fig.savefig(temp_name)
      mlflow.log_artifact(temp_name, "residuals.png")
    finally:
      temp.close() # Delete the temp file

    display(fig)
    return run.info.run_id

# COMMAND ----------

params = {
  "n_estimators": 100,
  "max_depth": 5,
  "random_state": 42
}

log_rf(experimentID, "expected_punt_returns-rf RUN", params, X_train, X_test, y_train, y_test)

# COMMAND ----------

# Log the trained model with MLflow and package it with feature lookup information. 
fs.log_model(
  model,
  artifact_path="model_packaged",
  flavor=mlflow.lightgbm,
  training_set=training_set,
  registered_model_name="expected_punt_return_yardage"
)
