import os
import requests
import numpy as np
import pandas as pd

def create_tf_serving_json(data):
  return {'inputs': {name: data[name].tolist() for name in data.keys()} if isinstance(data, dict) else data.tolist()}

def score_model(dataset):
  url = 'https://adb-8756109169069044.4.azuredatabricks.net/model/expected_punt_return_yardage/5/invocations'
  headers = {'Authorization': f'Bearer {os.environ.get("DATABRICKS_TOKEN")}'}
  data_json = dataset.to_dict(orient='split') if isinstance(dataset, pd.DataFrame) else create_tf_serving_json(dataset)
  response = requests.request(method='POST', headers=headers, url=url, json=data_json)
  if response.status_code != 200:
    raise Exception(f'Request failed with status {response.status_code}, {response.text}')
  return response.json()

if __name__ in "__main__":
    label = 'kickReturnYardage'
    prediction_record = pd.read_csv('./data/raw/prediction_record.csv')
    os.environ["DATABRICKS_TOKEN"] = "dapi148248f8e8fdb8e7b424311c7f259cc3-3"
    # Drop label column for inference
    prediction_record = prediction_record.drop([label], axis=1)
    # Call the score_model function and return a payload
    score_model_payload = score_model(prediction_record)
    print(score_model_payload)
    
    