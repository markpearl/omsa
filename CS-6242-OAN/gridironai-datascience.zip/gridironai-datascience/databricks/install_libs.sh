#!/bin/bash
/databricks/python/bin/pip install astroid==2.5.6
/databricks/python/bin/pip install azure-common==1.1.27
/databricks/python/bin/pip install azure-core==1.13.0
/databricks/python/bin/pip install azure-identity==1.6.0
/databricks/python/bin/pip install azure-keyvault-secrets==4.2.0
/databricks/python/bin/pip install azure-storage-blob==12.8.1
/databricks/python/bin/pip install bcrypt==3.2.0
/databricks/python/bin/pip install certifi==2020.12.5
/databricks/python/bin/pip install cffi==1.14.5
/databricks/python/bin/pip install chardet==4.0.0
/databricks/python/bin/pip install colorama==0.4.4
/databricks/python/bin/pip install cryptography==3.4.7
/databricks/python/bin/pip install idna==2.10
/databricks/python/bin/pip install isodate==0.6.0
/databricks/python/bin/pip install isort==5.8.0
/databricks/python/bin/pip install joblib==1.1.0
/databricks/python/bin/pip install mccabe==0.6.1
/databricks/python/bin/pip install msal==1.11.0
/databricks/python/bin/pip install msal-extensions==0.3.0
/databricks/python/bin/pip install msrest==0.6.21
/databricks/python/bin/pip install numpy==1.20.3
/databricks/python/bin/pip install oauthlib==3.1.0
/databricks/python/bin/pip install pandas==1.2.4
/databricks/python/bin/pip install paramiko==2.7.2
/databricks/python/bin/pip install portalocker==1.7.1
/databricks/python/bin/pip install py4j==0.10.9
/databricks/python/bin/pip install pycparser==2.20
/databricks/python/bin/pip install PyJWT==2.1.0
/databricks/python/bin/pip install pylint==2.8.2
/databricks/python/bin/pip install PyNaCl==1.4.0
/databricks/python/bin/pip install python-dateutil==2.8.1
/databricks/python/bin/pip install pytz==2021.1
/databricks/python/bin/pip install pywinpty==0.5.5
/databricks/python/bin/pip install requests==2.25.1
/databricks/python/bin/pip install requests-oauthlib==1.3.0
/databricks/python/bin/pip install six==1.16.0
/databricks/python/bin/pip scikit-learn==1.0.1
/databricks/python/bin/pip scipy==1.7.2
/databricks/python/bin/pip Send2Trash==1.8.0
/databricks/python/bin/pip six==1.16.0
/databricks/python/bin/pip sklearn==1.1.0
/databricks/python/bin/pip install toml==0.10.2
/databricks/python/bin/pip threadpoolctl==3.0.0
/databricks/python/bin/pip install urllib3==1.26.4
/databricks/python/bin/pip install wrapt==1.12.1
/databricks/python/bin/pip install install plotly==5.1.0
/databricks/python/bin/pip install /dbfs/FileStore/wheels/src-0.1.0-py3-none-any.whl