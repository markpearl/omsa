gridironai
==========

This project is aimed at developing models with NFL games / events data to analyze impact of special teams on game outcomes.

Project Organization
--------------------

```
├── LICENSE
├── Makefile           <- Makefile with commands like `make data` or `make train`
├── README.md          <- The top-level README for developers using this project.
├── data
│   ├── external       <- Data from third party sources.
│   ├── interim        <- Intermediate data that has been transformed.
│   ├── processed      <- The final, canonical data sets for modeling.
│   └── raw            <- The original, immutable data dump.
│
│
├── notebooks  
│   └── model_predictions.ipynb  
		       <- Notebook created to retrieve predictions for the expected yards model in mlflow  
│
├── Scripts                <- Scripts folder with orchestrator script.
│   ├── run_nfl_pipepline.py <- Entrypoint script for expected punt returns model for debugging locally
│
│
├── requirements.txt   <- The requirements file for reproducing the analysis environment, e.g.
│                         generated with `pip freeze > requirements.txt`
│
├── setup.py           <- makes project pip installable (pip install -e .) so src can be imported
├── src                <- Source code for use in this project.
│   ├── __init__.py    <- Makes src a Python module
│   │
│   ├── data           <- Scripts to download or generate data
│   │   └── init_it.py Makes src a Python module
│   │   └── azure_blob.py Helper class to access azure blob data source
│   │   └── pypsark.py Helper class for databricks delta and spark operations
│   │   └── join_games_plays.sql SQL containing join query for scouts and plays data
│   │   └── nfl_data_create_tables.sql DDL script for creating database tables in Azure SQL
│   │
│   ├── features       <- Scripts to turn raw data into features for modeling
│   │   └── build_features.py Script to calculate features the expected return yards model
│   │   └── build_feature_store.py Script to create databricks feature store
│   │   └── build_features_prepunt.py Script to calculate features for the pre punt model
│   │
│   ├── models         <- Scripts to train models and then use trained models to make
│   │   │                 predictions
│   │   └── train_model.py Script to train model for expected yards with databricks feature store
│   │   └── train_model_no_fs.py Script to train model for expected yards without databricks feature store
│   │   └── train_model_pre_punt.py Script to train pre punt model 
```



---
Databricks Pipeline
---
1) Navigate to the following: Databricks URL for the project: https://adb-8756109169069044.4.azuredatabricks.net/?o=8756109169069044#
2) Navigate to the jobs url: https://adb-8756109169069044.4.azuredatabricks.net/?o=8756109169069044#job/87/tasks to run the pipeline and select "Run Now", and this will orchestrate the pipeline.

---

Visualization Usage Instructions

---

The Tableau workboos has two dashboards that make up the visualization, Macro Level Overview and Punt Factors Analysis.

`<b>`Macro Level Overview:`</b>` The Macro Level Overview shows the performance of the entire league's actual return yardage compared to the expected
return yardage for the 2020 season. Below the league view is the team specific view. This can be updated by selecting a team from the filters
on the right panel, which will update the game-by-game data for the chosen team. The top filter affects the Away Games panel and the bottom
filter affects the Home Games panel, although the dashboard is designed to have the same team selected for both filters.

`<b>`Punt Factor Analysis:`</b>` The Punt Factor Analysis provides an overview of a single play from a game. The user can take a Game ID from the
Macro Level Overview dashboard and select it using the GameId filter to narrow down the plays to just those from a specific game. Below the Feature
Values panel is an overview of all the punts in the game, and the user can choose a specific punt from that list to fill in the visualization.
This visualization will now show a scoreboard with the game situation, as well as a view of the players on the field and their positions at the time
the returner catches the ball.

---

Visualization Installation Instructions

---

The dashboard is currently hosted online at `https://prod-ca-a.online.tableau.com/t/markstableauonline/views/Gridiron_v4/PuntFactorAnalysis/058a9a00-858e-4134-910c-1b3de1cf45d5/11a89435-4236-4699-92f6-84079722747b?:showAppBanner=false&:origin=viz_share_link&:display_count=n&:showVizHome=n` for viewing. 

Please user the following user and password when logging into Tableau Online:

```
user: markpearl7@gmail.com
```


```
pass: MDig_03199319
```


To run the project locally, you can open the Tableau workbook Gridiron_vF. There are a few requirements to install and run the visualization locally:

1. The Databricks data source must be running and connected to the Tableau workbook.
   a. Go to Databricks, go to the compute tab, select `gridiron_singlenode`, and select start. Wait for the server to start.
   b. Go to the Tableau Workbook Data Source tab and edit the connection `adb-8756109169069044.4.azuredatabricks.net`. Set Authentication to OAuth/Azure AD and set the endpoint to `https://login.microsoftonline.com/common`. This will open the Microsoft AD to log you in to access the Data Source.
2. The Databricks model must be running and serving responses through an HTTP request.
   a. In Databricks, select the Machine Learning environment.
   b. Go to models and select expected_punt_return_yardage.
   c. Click on Use Model for Inference, select Real-Time, and select Enable Serving.
3. TabPy must be installed and running locally.
   a. In a local terminal, run `pip install tabpy` to install TabPy.
   b. In the same terminal, run `tabpy` to turn on the TabPy server.
   c. In a seperate terminal tab, run the script `return_model.py` to connect it to the TabPy server and deploy the model.
4. An Analytical Extension must be added to Tableau to use TabPy.
   a. In Tableau, go to Settings and Performance and select Manage Analytics Extension Connection...
   b. Put localhost as the hostname and 9004 as the port
5. Add images to the Tableau repository.
   a. Download `logos.zip` and unzip the file.
   b. Locate your `My Tableau Repository` folder, select the shapes subfolder, and create a Logos subfolder.
   c. Move all of the images from the `logos.zip` file to the newly created Logos folder.

---

<p><small>Project based on the <a target="_blank" href="https://drivendata.github.io/cookiecutter-data-science/">cookiecutter data science project template</a>. #cookiecutterdatascience</small></p>
